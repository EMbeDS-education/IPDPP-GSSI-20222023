# StatsAndComputing20202021
Slides for course IPDP academic year 2020/20201
